#include <stdlib.h>
#include <stdio.h>
#include "queue.h"

//Initialize the queue before usage
int queue_init(struct queue *queue){
  queue->item_cnt = 0;
  queue->items = NULL;
  queue->capacity = 0;
}

// Insert an element into the priority queue
int queue_push(struct queue *queue, int pri){ // pri should point to the highest priority

  // Increase mamory capacity if needed
  if (queue->item_cnt == queue->capacity){
    queue->capacity = (int)(queue->capacity + 8);

    // Allocate new memory
    queue->items = realloc(queue->items,sizeof(void *)* queue->capacity);

    // Checks if items has been made correctly
    if (queue->items == NULL){
      return 1;
    }
  }

  // Run Find the right place in items and place pri there
  for (int i=0; i < queue->item_cnt; i++) {
    if (pri < queue->items[i]) {
      int temp = pri;
      int temp2 = queue->items[i];

      // After the new item has been placed correctly, we moce the rest of the array 1
      // in order to keep rest of the array
      for (int j=i; j<queue->item_cnt; j++) {
        queue->items[i] = temp;
        temp = temp2;
        temp2 = queue->items[i+1];
      }
      break;
    }
  }

  if (queue->item_cnt == 0) {
    queue->items[0] = pri;
  }

  // Add one to item count
  queue->item_cnt++;

  return 0;
}

//Pop the maximum priority out of the queue and make a new max priority item
int queue_pop(struct queue *queue, int *pri_ptr) {

  // Test if 0 items in que
  if (queue->item_cnt == 0) {
    return 2;
  }

  // Send the biggest element out to pri_ptr
  *pri_ptr = queue->items[queue->item_cnt]; // THERE IS A MISTAKE IN THIS LINE

  // We are now done and have an array which is 1 smaller
  queue->item_cnt = queue->item_cnt-1;

  // DEBUG
  printf("pri: %d\n", queue->items[queue->item_cnt]); // TYING TO FIX ERROR ABOVE
  printf("item_cnt: %d\n", queue->item_cnt); // TYING TO FIX ERROR ABOVE
  printf("test: %d\n", queue->items[2]); // TYING TO FIX ERROR ABOVE

  // Make capacity smaller if needed
  if (queue->item_cnt < (int)(queue->capacity * 0.5)) {
    queue->capacity = (int)(queue->capacity * 0.8);
    queue->items = realloc(queue->items,sizeof(void *)* queue->capacity);

    // Check if items exist
    if (queue->items == NULL){
      return 1;
    }
  }
  return 0;
}

//Destroy the queue after usage
int queue_destroy(struct queue *queue){
  free(queue->items);
  return 0;
}
