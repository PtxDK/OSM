#include <cswitch.h>
#include "proc/syscall.h"
#include "write.h"
#include "drivers/device.h"
#include "drivers/gcd.h"
#include "drivers/metadev.h"
#include "kernel/assert.h"
#include "drivers/polltty.h"
#include "lib/libc.h"
#include "fs/vfs.h"
#include "vm/memory.h"
#include "proc/process.h"

int read(int filehandle, void *buffer, int length){

    device_t *dev;
    gcd_t *gcd;
    int len;
    len = length;
    if(filehandle != FILEHANDLE_STDOUT){
      return -1;
    }

    dev = device_get(TYPECODE_TTY, 0);
    KERNEL_ASSERT(dev != NULL);


    gcd = (gcd_t *)dev->generic_device;
    KERNEL_ASSERT(gcd != NULL);

    len = gcd->read(gcd, buffer, len);
    KERNEL_ASSERT(len >= 0);

    return len;

}
