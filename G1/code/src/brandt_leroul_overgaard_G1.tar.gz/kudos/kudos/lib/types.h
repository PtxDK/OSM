/*
 * Architecture-specific integer typedefs
 */

#ifndef LIB_TYPES_H
#define LIB_TYPES_H

#include <types.h> // Includes mips/types.h or x86_types.h as appropriate.

#endif
