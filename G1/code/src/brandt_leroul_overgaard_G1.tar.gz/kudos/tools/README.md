# Tools

This directory contains YAMS helper scripts along with a script that generates
an installer script for installing both a cross-compiler, YAMS, and the YAMS
helper scripts.

Some of these scripts are aimed towards the MIPS target only.
